<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="A Web technology that enable schools build, publish and check their termly result without stress">
  
  <title>School Result Builder, School Result Checker and Publisher</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  <meta name="keywords" content="School result builder,School Result Checker,School Result Publisher, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="School Result Builder, Publisher and Checker">
<meta property="og:url" content="https://resultchecker.com.ng/">
<meta property="og:site_name" content="Result Builder and Checker">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="School Result Builder, Publisher and Checker">
<link rel="canonical" href="https://www.resultchecker.com.ng">

</head>
<body>
  <section class="extMenu10 menu cid-sJhAacfKMm" once="menu" id="extMenu11-s">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="cid-sHo804aiLr mbr-parallax-background" id="header2-7">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(35, 35, 35);">
    </div>
    <div class="container-fluid">
        <div class="row justify-content-space-between">
            <div class="col-md-12 col-lg-6 col-xl-6 text-element">
                <h2 class="mbr-section-title mbr-fonts-style mbr-white mbr-bold display-2">Online Result Checker</h2>
                <div class="underline align-left pb-3">
                     <div class="line"></div>
                </div>
                <h3 class="mbr-section-subtitle mbr-light mbr-fonts-style pb-3 mbr-white display-7">If your school already has a working website, and you want to integrate our result checking service to your school website, such that students will now be able to check their termly result on their offical school website. Our api is for you!, You could become a reseller and make cool cash by just reselling our result checker credits.&nbsp;</h3>
                <div class="mbr-section-btn"><a class="btn btn-md btn-white-outline display-4" href="signup.php"><span class="mbri-paper-plane mbr-iconfont mbr-iconfont-btn"></span>GET STARTED</a></div>
            </div>
            <div class="form-1 col-md-12  col-lg-4 col-xl-4" data-form-type="formoid">
                <!---Formbuilder Form--->
                <form action="./api/checker.php" enctype="multipart/form-data" target="DoSubmit" method="POST" class="mbr-form form-with-styler" onsubmit="DoSubmit = window.open('about:blank','DoSubmit','width=950,height=600,toolbar=0,scrollbars=1,resizable=1');">
                            <div class="row">
                                <input type="hidden" name="type" value="result" id="type-header2-7">
                                <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
                                </div>
                            </div>
                            <div class="dragArea row">
                                <div class="col-md-6 form-group " data-for="name">
                                    <input type="text" name="sid" placeholder="School ID" data-form-field="schoolid" required="required" class="form-control px-2 display-7" id="sid-header2-7">
                                </div>
                                <div class="col-md-6 form-group " data-for="email">
                                    <input type="text" name="regno" placeholder="Student Reg Number" data-form-field="reg_no" required="required" class="form-control px-2 display-7" id="regno-header2-7">
                                </div>
  
                              <div data-for="year" class="col-md-6 form-group ">
                                <select name="year" data-form-field="year" class="form-control px-2 display-7" id="year-header2-7">
 <option value="">RESULT SECTION</option>                                   
<option value="2023/2024">2023/2024</option>
<option value="2022/2023">2022/2023</option>
<option value="2021/2022">2021/2022</option>
<option value="2020/2021">2020/2021</option>
<option value="2019/2020">2019/2020</option>
<option value="2018/2019">2018/2019</option>
<option value="2017/2018">2017/2018</option>
<option value="2016/2017">2016/2017</option>
<option value="2015/2016">2015/2016</option>
<option value="2014/2015">2014/2015</option>
<option value="2013/2014">2013/2014</option>
</select>
                                </div>
                              <div data-for="term" class="col-md-6 form-group ">
                                <select name="term" data-form-field="term" class="form-control px-2 display-7" id="term-header2-7">
                                <option value="">RESULT TERM</option>
<option value="FIRST TERM">FIRST TERM</option>
<option selected="" value="SECOND TERM">SECOND TERM</option>
<option value="THIRD TERM">THIRD TERM</option>
                               </select>
                                </div>
                              <div data-for="class" class="col-md-6 form-group ">
                                <select name="class" data-form-field="class" class="form-control px-2 display-7" id="class-header2-7">
                                <option value="">CLASS</option>
<option class="sec" value="SS 3">SS 3</option>
<option class="sec" value="SS 2">SS 2</option>
<option class="sec" value="SS 1">SS 1</option>
<option class="sec" value="JSS 3">JSS 3</option>
<option class="sec" value="JSS 2">JSS 2</option>
<option class="sec" value="JSS 1">JSS 1</option>
<option class="gr" value="BASIC 6">BASIC 6</option>
<option class="gr" value="BASIC 5">BASIC 5</option>
<option class="gr" value="BASIC 4">BASIC 4</option>
<option class="gr" value="BASIC 3">BASIC 3</option>
<option class="gr" value="BASIC 2">BASIC 2</option>
<option class="gr" value="BASIC 1">BASIC 1</option>
<option class="gr" value="PRIMARY 6">PRIMARY 6</option>
<option class="gr" value="PRIMARY 5">PRIMARY 5</option>
<option class="gr" value="PRIMARY 4">PRIMARY 4</option>
<option class="gr" value="PRIMARY 3">PRIMARY 3</option>
<option class="gr" value="PRIMARY 2">PRIMARY 2</option>
<option class="gr" value="PRIMARY 1">PRIMARY 1</option>
<option class="gr" value="GRADE 6">GRADE 6</option>
<option class="gr" value="GRADE 5">GRADE 5</option>
<option class="gr" value="GRADE 4">GRADE 4</option>
<option class="gr" value="GRADE 3">GRADE 3</option>
<option class="gr" value="GRADE 2">GRADE 2</option>
<option class="gr" value="GRADE 1">GRADE 1</option>
<option class="nr" value="NURSERY 3">NURSERY 3</option>
<option class="nr" value="NURSERY 2">NURSERY 2</option>
<option class="nr" value="NURSERY 1">NURSERY 1</option>
<option class="nr" value="CRECHE">CRECHE</option>
<option class="nr" value="DAY CARE">DAY CARE</option>
<option class="nr" value="PLAYGROUP">PLAYGROUP</option>
<option class="nr" value="PRESCHOOL">PRESCHOOL</option>
<option class="nr" value="BABYSITTER">BABYSITTER</option>
                               </select>
                                </div>
                              <div data-for="classp" class="col-md-6 form-group ">
                                <select name="classp" data-form-field="classp" class="form-control px-2 display-7" id="classp-header2-7">
                                <option value="">SPEC.</option>
<option selected="" value="A">A</option>
<option value="B">B</option>
<option value="C">C</option>
<option value="D">D</option>
<option value="E">E</option>
<option value="F">F</option>
<option value="G">G</option>
<option value="H">H</option>
<option value="I">I</option>
                               </select>
                                </div>
                              <div class="col-md-6 form-group " data-for="pin">
                                    <input type="pin" name="pin" placeholder="Card Pin" data-form-field="pin" required="required" class="form-control px-2 display-7" id="pin-header2-7">
                                </div>
                                <div class="col-md-6 form-group " data-for="serial">
                                    <input type="serial" name="serial" placeholder="Card Serial" data-form-field="serial" required="required" class="form-control px-2 display-7" id="serial-header2-7">
                                </div>
                                
                                <div class="col-md-12 input-group-btn"><button type="submit" class="btn btn-form  btn-info btn-sm display-4">Check Now</button></div>
                            </div>
                        </form><!---Formbuilder Form--->
            </div>
        </div>
    </div>
              
</section>

<section class="extFeatures cid-sHECti3jfy" id="extFeatures7-9">

	

	
	<div class="container">
		<h2 class="mbr-fonts-style mbr-section-title align-center display-2"><strong>What We Offer</strong></h2>
		<h3 class="mbr-fonts-style mbr-section-subtitle align-center mbr-light pt-3 mb-3 display-5">This are the main features of our result computing system</h3>

		<div class="row justify-content-left pt-5">
			<div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-website-theme"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Multiple Result Template</h4>

					<p class="mbr-text mbr-fonts-style align-left display-7">We have design a free school  Termly result templates for you to select from with two or three C/A to choose from.<br><br></p>
				</div>
			</div>

			<div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-devices"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Automatic Result computing</h4>

					<p class="mbr-text mbr-fonts-style align-left display-7">Our system Compute the Total, Average and Subject score automatically as you are inputing figures.<br><br></p>
				</div>
			</div>

			<div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-watch"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Result Checker Pin Generator</h4>
					<p class="mbr-text mbr-fonts-style align-left display-7">Result Checker Pin generating have not been this easy, our system generate and print result checking pins to check the results. </p>
				</div>
			</div>

			<div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-lock"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Data Security &nbsp; <br>Module</h4>
					<p class="mbr-text mbr-fonts-style align-left display-7">Any pin and result compiled by our system are encripted with a well structure security logic that only our server can decode.<br><br> </p>
				</div>
			</div>
            <div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-upload"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Result Publishing and Checking</h4>
					<p class="mbr-text mbr-fonts-style align-left display-7">We provide advanced result and checking technology that simplifies both processes. Just fill in some basic information, click a button and you are done!. </p>
				</div>
			</div>
            <div class="col-md-12 col-lg-4 mt-5 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-left">
						<span class="mbr-iconfont mbri-setting2"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-left pb-2 display-5">Offline Result Builder Module.</h4>
					<p class="mbr-text mbr-fonts-style align-left display-7">With our Results Editor processor, editor can work on student results without any aid, just the click of a mouse.<br><br><br> </p>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="features16 cid-sHEL3l4hzm" id="features16-c">

    

    
    <div class="container-fluid">
        <div class="row main align-items-center">
            <div class="col-md-6 image-element align-self-stretch">
                <div class="img-wrap" style="width: 80%; height: 80%;">
                    <img src="assets/images/mbr-1328x891.jpg" alt="" title="">
                </div>
            </div>
            <div class="col-md-6 text-element">
                <div class="text-content">
                    <h2 class="mbr-title pt-2 mbr-fonts-style align-left mbr-white display-5"><strong>Your School Don''t have a Website?</strong></h2>
                    
                    <div class="mbr-section-text">
                        <p class="mbr-text pt-3 mbr-light mbr-fonts-style align-left mbr-white display-7">
                            If you are looking how to setup a responsive website for your school, we have your back covered. As we have a school website templates/portal we developed for you. Using our school website templates will fasting and aslo reduce the cost of building school website for your school to zero.</p>
                    </div>
                    <div class="mbr-section-btn pt-3 align-left"><a class="btn btn-md btn-info display-4" href="./school-portal-script.php">CHECK HOW</a></div>
                </div>
            </div>
        </div>
    </div>          
</section>

<section class="carousel slide testimonials-slider cid-sHFf5CUOd2" data-interval="false" id="testimonials-slider1-h">
    
    

    

    <div class="container text-center">
        <h2 class="mbr-section-title pb-3 align-center mbr-fonts-style display-2">What&nbsp;<strong>our clients says</strong></h2>

        <div class="carousel slide" role="listbox" data-pause="true" data-keyboard="false" data-ride="carousel" data-interval="5000">
            <div class="carousel-inner">
                
                
            <div class="carousel-item">
                    <div class="user col-md-8">
                        <div class="user_image">
                            <div class="user_image_inner">
                                <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="" title="">
                            </div>
                        </div>
                        <div class="user_name mbr-bold mbr-fonts-style display-5">Mr John Mbanefo</div>
                        <div class="user_desk mbr-light mbr-fonts-style display-7"><strong>Class Teache</strong>r</div>
                        <div class="user_text pt-3">
                            <p class="mbr-fonts-style display-7">
                                The result builder is best to none and very easy to use and also you can work on the student result without internet connection. 
                            </p>
                        </div>
                    </div>
                </div><div class="carousel-item">
                    <div class="user col-md-8">
                        <div class="user_image">
                            <div class="user_image_inner">
                                <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="" title="">
                            </div>
                        </div>
                        <div class="user_name mbr-bold mbr-fonts-style display-5">Blessing Olatunji</div>
                        <div class="user_desk mbr-light mbr-fonts-style display-7"><strong>
                            Principal
                        </strong></div>
                        <div class="user_text pt-3">
                            <p class="mbr-fonts-style display-7">
                                The customized result templates is what i like the most, because i still have the same result sheet in an online version
                            </p>
                        </div>
                    </div>
                </div><div class="carousel-item">
                    <div class="user col-md-8">
                        <div class="user_image">
                            <div class="user_image_inner">
                                <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="" title="">
                            </div>
                        </div>
                        <div class="user_name mbr-bold mbr-fonts-style display-5">Hassan Abubarka</div>
                        <div class="user_desk mbr-light mbr-fonts-style display-7"><strong>
                            Headmaster
                        </strong></div>
                        <div class="user_text pt-3">
                            <p class="mbr-fonts-style display-7">
                                Result Checker management are fantastic. I must commend them for this perfect solution to online school result builder, publisher and checking
                            </p>
                        </div>
                    </div>
                </div></div>

            <div class="carousel-controls">
                <a class="carousel-control-prev" role="button" data-slide="prev">
                  <span aria-hidden="true" class="mbri-arrow-prev mbr-iconfont"></span>
                  <span class="sr-only">Previous</span>
                </a>
                
                <a class="carousel-control-next" role="button" data-slide="next">
                  <span aria-hidden="true" class="mbri-arrow-next mbr-iconfont"></span>
                  <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</section>

<section class="extFooter cid-sHo7yQujkP" id="extFooter18-4">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/bootstrapcarouselswipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/mbr-testimonials-slider/mbr-testimonials-slider.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>