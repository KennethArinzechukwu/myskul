<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="An insight  on how our School Result Checker and  Builder web technology works by providing steps on how they work">
  
  <title>How Our School Result Builder and Checker Work</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  <meta name="keywords" content="school result builder software, online school result builder, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Resultchecker | Understanding How Our System Works">
<meta property="og:url" content="https://resultchecker.com.ng/hiw.php">
<meta property="og:site_name" content="Result Builder and Checker">
<link rel="canonical" href="https://www.resultchecker.com.ng/hiw.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJhAacfKMm" once="menu" id="extMenu11-s">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sHGaop2fmx" id="design-block-j">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>How it works</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.html">Home</a> &nbsp;/&nbsp; <span class="text-success">How it works</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="timeline1 cid-sHGdVgItWO" id="timeline1-l">

    

    

    <div class="container-fluid align-center">
        <h2 class="mbr-section-title mbr-fonts-style display-2">How it<strong> works</strong></h2>
        <div class="underline align-center pb-3">
            <div class="line"></div>
        </div>
        

        <div class="container timelines-container pt-5" mbri-timelines="">
            <!--1-->
            <div class="row timeline-element first-separline separline">
                 <div class="timeline-date-panel col-xs-12 col-md-3 align-left">         
                    <div class="time-line-date-content">
                        <p class="mbr-timeline-date mbr-fonts-style display-7">
                            Step One</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Sign Up</h4>
                        
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                            For you  to start using our system,  you have to sign up for your school, and buying a result checker credit(s) <a href="./signup.php">click here</a> to get started.</p>
                     </div>
                </div>
            </div>
            <!--2-->
            <div class="row timeline-element  separline">
                <div class="timeline-date-panel col-xs-12 col-md-3 align-left">
                    <div class="time-line-date-content">
                        <p class="mbr-timeline-date mbr-fonts-style display-7">Step Two</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Add Students And Add Editors/Teachers</h4>
                        
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                            Login to your school admin dashboard and add students and teachers to your datasource. also update the school logo and other informations from the settings page.&nbsp;</p>
                    </div>
                </div>
            </div>
            <!--3-->
            <div class="row timeline-element separline">
                <div class="timeline-date-panel col-xs-12 col-md-3 align-left">
                    <div class="time-line-date-content">
                        <p class="mbr-timeline-date mbr-fonts-style display-7">Step Three</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Add Result and give editors import code</h4>
                              
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                           The editors(teachers) you add on step two will now build termly class result using our online/offline result builder technology to compute the result. The editors using the import code give to them by the school admin to import students and results to our result builder and start building result.&nbsp;<br>  <a href="https://builder.resultchecker.com.ng" target="_blank">click here</a> to see our result builder in action.<br><br>Note: You will need to upload the result you computed online by using the import code, editor username and password. this will enable you to access the result from another device.</p>
                    </div>
                </div>
            </div>
            <!--4-->
            <div class="row timeline-element  separline">
                <div class="timeline-date-panel col-xs-12 col-md-3 align-left">
                    <div class="time-line-date-content">
                        <p class="mbr-timeline-date mbr-fonts-style display-7">Step Four</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Publish Result</h4>
                        
                        <p class="mbr-timeline-text mbr-fonts-style display-7">When the editors(teachers) are through with the result computation, they can now publish the result online using the editor account information you setup for them in step two. <br><br>After they have uploaded the result, the school admin will have to change the result status to published. This will make it posible for students to check that particular result<br><br>Note: The previllage to change the result status it exclusively reserved for the school admin only and can't be executed by the editor..<br><br></p>
                    </div>
                </div>
            </div>
            <!--5-->
            <div class="row timeline-element separline">
                <div class="timeline-date-panel col-xs-12 col-md-3 align-left">
                    <div class="time-line-date-content">
                        <p class="mbr-timeline-date mbr-fonts-style display-7">
                            Step Five</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Give students pin</h4>
                        
                        <p class="mbr-timeline-text mbr-fonts-style display-7">
                            As you signup and pay for the result checker credit &nbsp;through our reseller or direct to from us, You will &nbsp;be credited with the volume of credit(s) you purchased, you can now generate  result checker pin wth the credit and give to the students for them to check their result with it.
                        </p>
                    </div>
                </div>
            </div>
            <!--6-->
            <div class="row timeline-element">
                <div class="timeline-date-panel col-xs-12 col-md-3 align-left">
                    <div class="time-line-date-content">
                       <p class="mbr-timeline-date mbr-fonts-style display-7">Step Six</p>
                    </div>
                </div>
                <span class="iconBackground"></span>
                <div class="col-xs-12 col-md-9">
                    <div class="timeline-text-content">
                        <h4 class="mbr-timeline-title pb-3 mbr-fonts-style display-5">Student Check Result</h4>
                        
                        <p class="mbr-timeline-text mbr-fonts-style display-7">The students or parents can now use the pin given to them, to check and print the result published by the editors(class teacher). on our web site or the school website if our result checker is integrated on their server.
<br> <a href="result-checker-script.php">Read more</a> on intergration.<br><br><strong>Note:</strong> That you can only use one pin for a studend per section. if you neen more clearification, goto our <a href="./faq.php">Faq page</a><br></p>
                    </div>
                </div>
            </div>
            <!--7-->
            
            <!--8-->
            
            <!--9-->
            
            <!--10-->
            
            <!--11-->
            
            <!--12-->
            
        </div>
    </div>
</section>

<section class="extFooter cid-sJhVoVTYRu" id="extFooter18-t">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>