<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="We have a flexible result checking pin pricing that  works for every body no matter the population of your school.">
  
  <title>Buy School Result Checker and  Builder Pin and Serial Credit.</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  <meta name="keywords" content="school result builder software, online school result builder, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Buy School Result Checker and  Builder Pin and Serial">
<meta property="og:url" content="https://resultchecker.com.ng/pricing.php">
<meta property="og:site_name" content="Buy School Result Checker and  Builder Pin and Serial">
<link rel="canonical" href="https://www.resultchecker.com.ng/pricing.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJhAacfKMm" once="menu" id="extMenu11-s">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sHNumsYohv" id="design-block-n">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>Pricing</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.html">Home</a> &nbsp;/&nbsp; <span class="text-success">Pricing</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="extPricingTables cid-sHNBJTIOYA" id="extPricingTables2-p">

    

    
    <div class="container">
        <h2 class="mbr-fonts-style mbr-section-title align-center mbr-light display-2"><strong>Check out our prices</strong></h2>
        <h3 class="mbr-fonts-style mbr-section-subtitle align-center mbr-light pt-2 display-7">Buy credit to enable you generate result checking cards.&nbsp;</h3>
        
        <div class="media-container-row pt2">
            <div class="plans col-md-12 col-12 mx-3 my-2  mt-3 justify-content-center col-lg-4">
                <div class="plan-card">
                    <div class="plan-header text-center pb-4">
                        
                        <h2 class="mbr-fonts-style plan-title align-center pt-5 mbr-black display-2"><strong>Standard</strong></h2>
                    
                        <h3 class="mbr-fonts-style plan-subtitle align-center mbr-light display-4">From 10-499 Credits</h3>
                        <div class="plan-price">
                            <span class="price-value mbr-fonts-style display-5">
                                ₦
                            </span>
                            <span class="price-figure mbr-fonts-style display-2"><strong>1,500</strong></span>
                        </div>
                        <div class="plan-descr pt-2 mbr-fonts-style display-7"><strong>Per Credits</strong></div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list pb-4 align-center">
                            <ul class="list-group list-group-flush mbr-fonts-style display-4">
                                                             <li class="list-group-item"><strong>1 Credit will Generate One Result Checker Card pin</strong></li><li class="list-group-item"><strong>1 Result checker Card pin will check result for a full academic section 
</strong></li><li class="list-group-item"><strong>Credit Never Expire</strong></li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center pb-4"><a href="./signup.php" class="btn btn-info display-4">Get Started</a></div>
                    </div>
                </div>
            </div>

            <div class="plans  col-md-12 col-12 mx-3 my-2 mt-3 justify-content-center col-lg-4">
                <div class="plan-card">
                    <div class="plan-header text-center pb-4">
                        <h3 class="plan-favorite mbr-white mbr-fonts-style pb-3 pt-3 mb-5 display-7">
                            Reseller</h3>
                        <h2 class="mbr-fonts-style plan-title align-center pt-5 mbr-black display-2"><strong>Bussiness</strong></h2>
                    
                        <h3 class="mbr-fonts-style plan-subtitle align-center mbr-light display-4">From 500-999 Credits</h3>
                        
                        <div class="plan-price">
                            <span class="price-value mbr-fonts-style display-5">
                                ₦
                            </span>
                            <span class="price-figure mbr-fonts-style display-2"><strong>1,200</strong></span>
                        </div>
                        <div class="plan-descr pt-2 mbr-fonts-style display-7"><strong>Per Credits</strong></div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list pb-4 align-center">
                            <ul class="list-group list-group-flush mbr-fonts-style display-4">
                                <li class="list-group-item"><strong>1 Credit will Generate One Result Checker Card pin</strong></li><li class="list-group-item"><strong>1 Result checker  Card pin will check result for a full   academic section 
</strong></li><li class="list-group-item"><span style="background-color: transparent; font-size: 1rem;"><strong>Credit Never Expire</strong></span><br></li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center pb-4"><a href="./signup.php" class="btn btn-info display-4">Get Started</a></div>
                    </div>
                </div>
            </div>

            <div class="plans  col-md-12 col-12 mx-3 my-2  mt-3 justify-content-center col-lg-4">
                <div class="plan-card">
                    <div class="plan-header text-center pb-4">
                        
                        <h2 class="mbr-fonts-style plan-title align-center pt-5 mbr-black display-2"><strong>Premium</strong></h2>
                        <h3 class="mbr-fonts-style plan-subtitle align-center mbr-light display-4">From 1000-2000 Credits</h3>
                        <div class="plan-price">
                            <span class="price-value mbr-fonts-style display-5">
                                ₦
                            </span>
                            <span class="price-figure mbr-fonts-style display-2"><strong>1,000</strong></span>
                        </div>
                        <div class="plan-descr pt-2 mbr-fonts-style display-7"><strong>Per Credits</strong></div>
                    </div>
                    <div class="plan-body">
                        <div class="plan-list pb-4 align-center">
                            <ul class="list-group list-group-flush mbr-fonts-style display-4">
                                <li class="list-group-item"><strong>1 Credit will Generate One Result Checker Card pin</strong></li><li class="list-group-item"><strong>1 Result checker Card pin will check result for a full academic section 
</strong></li><li class="list-group-item"><strong>Credit Never Expire</strong></li>
                            </ul>
                        </div>
                        <div class="mbr-section-btn text-center pb-4"><a href="./signup.php" class="btn btn-info display-4">Get Started</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="extFooter cid-sJhVvZ0mXs" id="extFooter18-u">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>