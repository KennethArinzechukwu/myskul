<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="twitter:card" content="summary_large_image"/>
<meta name="twitter:image:src" content="assets/images/signup.php-meta.jpg"/>
<meta property="og:image" content="assets/images/signup.php-meta.jpg"/>
<meta name="twitter:title" content="Sign Up For New Account On Resultchecker"/>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="Get Started by creating account with us, it's free No first payment before use, try and start paying if you like our service.">
  
  <title>Sign Up For New Account On Resultchecker</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  <link rel="canonical" href="https://www.resultchecker.com.ng/signup.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJAVHgIAQW" once="menu" id="extMenu11-2j">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sJAVH5UjKd" id="design-block-2f">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>Signup</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.html">Home</a> &nbsp;/&nbsp; <span class="text-success">Signup</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="cid-sJAVHaja8S" id="content7-2g">

    

    
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6 col-md-8 align-center">
                
                <h2 class="mbr-section-title align-center mbr-fonts-style mbr-bold display-2"><span style="font-weight: normal;">Account</span>&nbsp;Signup</h2>
            </div>
        </div>
    </div>
</section>

<section class="cid-sJAVHbUxt5 mbr-parallax-background" id="form3-2h">

    

    <div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(0, 0, 0);">
    </div>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="form-1 col-md-8 col-lg-8" data-form-type="formoid">
                <!---Formbuilder Form--->
                    <form action="./signup.php" method="POST" class="mbr-form form-with-styler">
                      <input type="hidden" name="action" value="signup" id="action-form3-2h">
                        <div class="dragArea form-row input-main border p-3">
                        			                            <div class="col-md-6 form-group" data-for="sname">
                                <label for="sname-form3-2h" class="form-control-label mbr-fonts-style display-7">School Name</label>
                                <input type="text" name="sname" data-form-field="sname" required="required" class="form-control display-7" value="" id="sname-form3-2h">
                                                            </div>
                            <div data-for="sphone" class="col-md-6 form-group">
                                <label for="sphone-form3-2h" class="form-control-label mbr-fonts-style display-7">School Phone</label>
                                <input type="text" name="sphone" data-form-field="sphone" class="form-control display-7" required="required" value="" id="sphone-form3-2h">
                                
                            </div>
                            <div data-for="sadd" class="col-md-12 form-group">
                                <label for="sadd-form3-2h" class="form-control-label mbr-fonts-style display-7">School Address</label>
                                <input type="text" name="sadd" data-form-field="sadd" class="form-control display-7" required="required" value="" id="sadd-form3-2h">
                                
                            </div>
                            <div data-for="semail" class="col-md-12 form-group">
                                <label for="semail-form3-2h" class="form-control-label mbr-fonts-style display-7">School Email</label>
                                <input type="email" name="semail" data-form-field="semail" class="form-control display-7" required="required" value="" id="semail-form3-2h">
                                
                            </div>

                            <div data-for="shuman" class="col-md-12 form-group">
                                <label for="shuman-form3-2h" class="form-control-label mbr-fonts-style display-7">What is the sum of 8 + 6 ?
        (security question)</label>
                                <input type="text" name="shuman" data-form-field="shuman" class="form-control display-7" required="required" value="" id="shuman-form3-2h">
                                 
                            </div>
                            
                            
                            
                            <div class="input-group-btn col-md-12"><button type="submit" class="btn btn-form btn-white-outline display-4">Create Account</button></div>
                            <p>
                                <br>
<a href="./login.php" class="text-white">I have account already</a>
                                </p>
                        </div>
                    </form><!---Formbuilder Form--->
                </div>
            </div>
        </div>
   
</section>

<section class="extFooter cid-sJAVHdVfxY" id="extFooter18-2i">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  <!-- The Modal -->
<div><div class="modal fade" id="confirm-info" tabindex="-1" role="dialog" aria-labelledby="confirm-infoLabel" aria-hidden="true">  <div class="modal-dialog  modal-dialog-centered" style="height:auto" role="document">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h6 class="modal-title">Signup Notification</h6>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Your Signup is not automatic, As your account <b>username and password</b> will be sent to the email address you signed up with. <br><br>So you are adviced to use a valid email address while signing up. also your account username and password may arrive your email address within 5-30mins of signup, but sometime it may take upto a maximum of 24hrs. This is to enable us verify the school information. <br>Furthe rmore, Account created with invalid school information will be terminated without notice.<br><br>
<strong>Note : </strong> Your account with us will still be on a trial mode which will be terminated automatically by our system after 2 months of not purchasing your first time credit with us.<br><br>
Thanks for choosing ResultChecker
      </div>
    </div>
  </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    if (localStorage.getItem("infosignup") === null) {
	setTimeout( function() { $('#confirm-info').modal('show');localStorage.setItem('infosignup', 'yes'); } , 3000);
}

});
</script>
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>