<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="All your questions as regards to our School Result Checker and School Result Builder are answered here">
  
  <title>Frequently Ask Question on our School Result Checker and Builder</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
    <meta name="keywords" content="school result builder software, online school result builder, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Resultchecker | Frequently Ask Question">
<meta property="og:url" content="https://resultchecker.com.ng/pricing.php">
<meta property="og:site_name" content="Result Builder and Checker">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Resultchecker | Frequently Ask Question">
<link rel="canonical" href="https://www.resultchecker.com.ng/faq.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJih23n4sT" once="menu" id="extMenu11-17">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sJih1WHkac" id="design-block-14">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>FAQ</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.html">Home</a> &nbsp;/&nbsp; <span class="text-success">faq</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="extAccordion cid-sK1BJFhQAC" id="extAccordion5-2x">

    


    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="mbr-section-title align-center mbr-fonts-style mbr-bold display-2"><span style="font-weight: normal;">Our</span> FAQ</h2>
                <h3 class="mbr-section-subtitle pt-2 align-center mbr-light mbr-fonts-style display-7">Below are anwsers to some important questions asked by our clients. If your question is not anwser below, please do contact us using our chatbot at the page footer, and we will be glad to anwser your questions.</h3>
            </div>
        </div>

        <div class="accordion-content">

            <div id="bootstrap-accordion_40" class="panel-group accordionStyles accordion " role="tablist" aria-multiselectable="true">
                <div class="row pt-3 justify-content-center">
                    <div class="col-md-12 col-lg-6 accordion-section">


                        <div class="card">
                            <div class="card-header" role="tab" id="headingOne">

                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse1_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">What is Resultchecker all about?</h4>
                                    </div>

                                </a>
                            </div>
                            <div id="collapse1_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">
                                    <p class="mbr-fonts-style panel-text display-4">Resultchecker.com.ng Is a School result management system, that enable schools compute, manage, and publish the student termly result without stress.&nbsp;<br></p>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" role="tab" id="headingTwo">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse2_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">What is Credit, and how do i get it ?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse2_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">The Credit is a kind of account wallet you use to pay for services we offer at resultchecker.com.ng.
<br>
<br>You can pay for our services such as Resultchecker Cards Generating, School Website Templates and more using your purchased credits.</p>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" role="tab" id="headingThree">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse3_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">What is scope, limit of the result checker card?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse3_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">The result checker card can only work for shool it was generated for, and the first student that first used the generated card to check his or her result. also by default it can be valid to check a perticular stuent result for the three terms, Namely  First, Second and Third term. and has a validity of 6 times check before it expires. 
<br>
<br>But the school admin can setup the maximum limit a card can be used by a student to check a result before it expires from the admin dashboard</p>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" role="tab" id="headingFour">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse4_40" aria-expanded="false" aria-controls="collapse4">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">How can i intergrate the result builder and cheker on our school website?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse4_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingFour" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">We have developed an API Modules, that when you upload it to your school server and configure it, will enable Teachers build results and students to check result on their school website without  the need to direct them to <a href="https://resultchecker.com.ng" target="_blank">www.resulthecker.com.ng</a> to check their termly result.&nbsp;
                                    <br><br><a href="https://resultchecker.com.ng/result-checker-script.php" target="_blank">Download Our API Module from here</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingFourone">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse41_40" aria-expanded="false" aria-controls="collapse41">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">How can i build the result?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse41_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingFourone" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">You can start building of result from the admin dashboard, also you can use our Progressive Web App(PWA) by visiting <a href="https://builder.resultchecker.com.ng">https://builder.resultchecker.com.ng</a> on your Smart Devices to have it installed on your device.
<br>
<br>Please Check our instructions on how to use the result builder offline on your Smartphone and computer/laptop by clicking here</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingFourtwo">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse42_40" aria-expanded="false" aria-controls="collapse42">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">What is school portal and how can i get it setup for my school?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse42_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingFourtwo" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">The school portal is a complete school website cum portal, that we developed for school who has no functioning or perfect school website of their own.<br><br>With our school portal script, our client can have a functioning school website within 72hours of purchasing it.&nbsp;<br>
<br>Contact us for more information on that.</p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-12 col-lg-6 accordion-section">





                        <div class="card">
                            <div class="card-header" role="tab" id="headingFive">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse5_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">How can i start using this service?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse5_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingFive" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4"><strong>Firstly : </strong>you must be a school admin, school ITC personel or approved by the school to set the result checking services for the school. 
<br>
<br><strong>Secondly :</strong> You have to signup for our service by <a href="signup.php">click here</a></p>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" role="tab" id="headingSix">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse6_40" aria-expanded="false" aria-controls="collapse5">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">What is result checker pin,  how to get it and it use?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse6_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingSive" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">
                                        It is an access token also called resultchecker card, generated by the school admin via the admin dashboard and given to student to check their termly result</p>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header" role="tab" id="headingSeven">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse7_40" aria-expanded="false" aria-controls="collapse6">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">Diffrent between Result Credit and card
<div>
</div><div><br></div></h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse7_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingSeven" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">In a simple explanation. 
<br>
<br>Result Credit:  is like your money in your bank, 
<br>while the result
<br>Checker card: is like the goods you purchase from the money in your bank account. 
<br>
<br>Example: if you have 500 credits in your account, you can use it to generate 500 result checker card for your school. 
<br>
<br>Also Result Credit can never expire while result checker card expire once it is used to check result.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingEight">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse8_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">Can i resell the result credit and make money?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse8_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingEight" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">No, as a school admin, you cannot resell your credits to others, as that feature is exclusively reserved for our Resellers. 
<br>
<br>For you to qualify as a reseller, you have to pay one a time non refundable  fee of <strong>₦50,000</strong> and we will setup your reseller account for you on our platform, were you can buy credit at a flat rate of <strong>₦1,200</strong>  and also have the facility to transfer credits to school that purchase from you. 
<br>
<br>Also your contact informtion will be included on our reseller page for easy contact by our clients close to your location for credit purchase. <br><a href="reseller.php">Click here</a> to goto our reseller page</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingEightone">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse81_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">How can i add and control teacher on my school account?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse81_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingEightone" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">On our platform, we call them editors, you can add umlimted editors as a sub account under the main admin school account to help build students class results more faster. When you add an editor account under your school, a user ID will be aumatically assign to that editor which you can now input the editor informations, password and save.and you will now have an editor that can help you build and pubish result for the school . repeat this until you are ok with the number of editors you want. 
<br>
<br>Note: That each editor added cost <strong>1</strong> credits from the School admin account. and also  the admin can suspend, modify and delete editor account if he or she so wishes.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" role="tab" id="headingEighttwo">
                                <a role="button" class="collapsed panel-title" data-toggle="collapse" data-core="" href="#collapse82_40" aria-expanded="false" aria-controls="collapse1">
                                    <span class="sign mbr-iconfont icon mbri-arrow-next inactive"></span>
                                    <div class="wrap">
                                        <h4 class="mbr-fonts-style header-text mbr-bold display-7">How can i intergrate your service to my existing school website?</h4>

                                    </div>

                                </a>
                            </div>
                            <div id="collapse82_40" class="panel-collapse noScroll collapse" role="tabpanel" aria-labelledby="headingEighttwo" data-parent="#bootstrap-accordion_40">
                                <div class="panel-body p-4">

                                    <p class="mbr-fonts-style panel-text display-4">We have developed an PHP Sdk that will enable schools intergrate our service to their existing school website.<br>Download our Sdk by going to our Api Intergration page for more information. &nbsp;<br>
<br><strong>Note:</strong> Your host must be running a <strong>PHP</strong> to have our sdk working on your school website.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="extFooter cid-sJih20UPGm" id="extFooter18-16">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/mbr-switch-arrow/mbr-switch-arrow.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>