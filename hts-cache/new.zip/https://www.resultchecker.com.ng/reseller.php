<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="Add extra cash to your bank account by reselling our result checker credit to school near you at a cheaper rate.">
  
  <title>Join our resellers and laugh to the bank, by reselling our credit to school closer to you.</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/datatables/data-tables.bootstrap4.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  <meta name="keywords" content="school result builder software, online school result builder, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Resultchecker | Buy Result Checker and Builder Credits">
<meta property="og:url" content="https://resultchecker.com.ng/reseller.php">
<meta property="og:site_name" content="Result Builder and Checker">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Resultchecker | Resale Result Checker and Builder Credits">
<link rel="canonical" href="https://www.resultchecker.com.ng/reseller.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJhWG4rFcn" once="menu" id="extMenu11-y">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sJhWFWWi1s" id="design-block-v">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>Reseller</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.php">Home</a> &nbsp;/&nbsp; <span class="text-success">Reseller</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="table1 section-table cid-sJijXWeqJ7" id="table1-19">

    

    
    <div class="container-fluid">
        <div class="media-container-row align-center">
            <div class="col-12 col-md-12">
                <h2 class="mbr-section-title mbr-fonts-style mbr-black display-2">Our <strong>Reseller</strong></h2>
                <div class="underline align-center pb-3">
                    <div class="line"></div>
                </div>
                <h3 class="mbr-section-subtitle mbr-light mbr-fonts-style pb-5 pt-3 display-7">To Join our reseller group, you will have to pay a Non Refundable fee of <strong>₦50,000</strong> after that, all your Credits Purchase will be at a flat rate of <strong>₦1,200</strong> any time you want to Purchase Credit, Also you will have the previllage to resale credits by transfering credits to school at your own rate. To Join our reseller package <strong><a href="join-reseller.php">Click Here</a></strong>.</h3>
                <div class="table-wrapper" style="width: 100%;">
                    <div class="container-fluid">
                        <div class="row search">
                            <div class="col-md-6"></div>
                            <div class="col-md-6">
                                <div class="dataTables_filter">
                                    <label class="searchInfo mbr-fonts-style display-7">Search:</label>
                                    <input class="form-control input-sm" disabled="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid scroll">
                            <table class="table table-striped isSearch" cellspacing="0" data-empty="No Reseller matching records found">
                            <thead>
                                <tr class="table-heads">
                                <th class="head-item mbr-fonts-style display-4"><strong>#</strong></th><th class="head-item mbr-fonts-style display-4"><strong>NAME</strong></th><th class="head-item mbr-fonts-style display-4"><strong>PHONE</strong></th><th class="head-item mbr-fonts-style display-4"><strong>LOCATION</strong></th><th class="head-item mbr-fonts-style display-4"><strong>CREDIT PRICE</strong></th></tr>
                            </thead>

                            <tbody>
                                Could not execute command