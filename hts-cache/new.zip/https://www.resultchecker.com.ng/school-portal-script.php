<!DOCTYPE html>
<html  >
<head>
  
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/logopit-1579212752175-1-122x115-122x115-2.png" type="image/x-icon">
  <meta name="description" content="Our responsive School Portal PHP Website Script enable schools to setup a complete school website without writing any programing code">
  
  <title>A complete responsive School Templates/Portal PHP Website Script</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons-bold/mobirise-icons-bold.css">
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons2/mobirise2.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.css">
  <link rel="stylesheet" href="assets/formstyler/jquery.formstyler.theme.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/datepicker/jquery.datetimepicker.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/formoid-css/recaptcha.css">
  <link rel="preload" as="style" href="assets/mobirise/css/mbr-additional.css"><link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
    <meta name="keywords" content="Responsive school website template,school result builder software, online school result builder, Nigeria online school result checker and publisher, online result checker, Nigeria online result checker">
<meta name="author" content="Ezeagu Onyeka Innocent">
<meta name="robots" content="index,follow">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="website">
<meta property="og:title" content="Responsive School Portal PHP Website Script">
<meta property="og:url" content="https://resultchecker.com.ng/school-portal-script.php">
<meta property="og:site_name" content="Result Builder and Checker">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="Responsive School Portal PHP Website Script">
<link rel="canonical" href="https://www.resultchecker.com.ng/school-portal-script.php">

</head>
<body>
  <section class="extMenu10 menu cid-sJtzorANhG" once="menu" id="extMenu11-1n">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="./">
                        <img src="assets/images/logopit-1579212752175-1-122x115.png" alt="Resultchecker" title="" style="height: 4rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="./">ResultChecker</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item">
                    <a class="nav-link link text-black display-4" href="./">Home</a>
                </li>
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./hiw.php">How it Works</a></li><li class="nav-item"><a class="nav-link link text-black display-4" href="./pricing.php">
                        Pricing</a></li><li class="nav-item dropdown"><a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Reseller</a><div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./reseller.php" aria-expanded="false">Our Reseller</a><a class="text-black dropdown-item display-4" href="./join-reseller.php">Become our reseller</a></div></li><li class="nav-item dropdown">
                    <a class="nav-link link text-black dropdown-toggle display-4" href="#" data-toggle="dropdown-submenu" aria-expanded="false">
                        Web Tools</a>
                    <div class="dropdown-menu"><a class="text-black dropdown-item display-4" href="./offline-school-result-builder-software.php">School Result Builder App</a><a class="text-black dropdown-item display-4" href="./school-portal-script.php" aria-expanded="false">School Website Templates</a><a class="text-black dropdown-item display-4" href="./result-checker-script.php" aria-expanded="false">API Intergration</a></div>
                </li>
                
                
                <li class="nav-item"><a class="nav-link link text-black display-4" href="./faq.php">
                        Faq</a></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-info display-4" href="./signup.php">SIGN UP</a> <a class="btn btn-sm btn-info-outline display-4" href="./login.php">

                    LOGIN</a></div>
        </div>
    </nav>
</section>

<section class="inner-header-section cid-sJtzolSkYC" id="design-block-1k">

     

    <section class="inner-header">
<div class="container">
	<div class="row">
		<div class="col-md-12 aligner">
			<h1 class="mbr-text mb-0 mbr-fonts-style display-2"><strong>Website Portal</strong></h1>
			<div class="breadcrumbs">
				<p class="mb-0"><a class="inner-header-link" href="index.html">Home</a> &nbsp;/&nbsp; <span class="text-success">Website Portal</span></p>
			</div>
		</div>
	</div>
</div>
</section>
</section>

<section class="extСontent cid-sK3wmL8mrK" id="extContent9-31">
    
    
    <div class="container">
        <div class="row">
            <div class="col-lg-6 title-col m-auto align-left order-2">
                <div class="text-wrap align-left">
                    
                    <h2 class="mbr-section-title pb-4 mbr-semibold mbr-black mbr-fonts-style display-2">Website Portal</h2>
                    <p class="mbr-text mbr-black mbr-regular mbr-light mbr-fonts-style display-7">If you are a private school owner or school administrator, and you are looking for an affordable school website portal for your school, then you have come to the right place. Resultchecker responsive School Portal PHP Website Script enable schools to setup a complete school website without writing any programing code.&nbsp;<br><br>Our school portal is developed with modern web technology, Such as HTML5,CSS3 and a clean code outline. It can render in all types of browser such as
<br>mobile and pc browser without loosing it design.
<br>The use frendily navigation makes it a must use for all school.<br></p>
                </div>
            </div>
            <div class="col-lg-6 img-col">
                <img class="img2" src="assets/images/mbr.png" alt="" title="">
                <img src="assets/images/mbr-1.jpg" alt="" title="">
            </div>

        </div>
    </div>
</section>

<section class="extFeatures cid-sJYjDAJDWJ mbr-parallax-background" id="extFeatures8-2q">

	

	<div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(27, 161, 226);">
	</div>
	<div class="container">
		<h2 class="mbr-fonts-style mbr-section-title align-center display-5"><strong>Our portal modules</strong></h2>
		
		<div class="row justify-content-center pt-4">
			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-home"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Homepage</h4>
				</div>
			</div>

			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-info"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">About Us</h4>
				</div>
			</div>

			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-letter"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Contact Us</h4>
				</div>
			</div>

			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-photos"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Photo Gallery</h4>
				</div>
			</div>
			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbrib-contact-form"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Employment Form</h4>
				</div>
			</div>
			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-users"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Students Data</h4>
				</div>
			</div>
			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-user"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Editors Data</h4>
				</div>
			</div>
			<div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-credit-card"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Admission Processor</h4>
				</div>
			</div>
            <div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbrib-search"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Our Result Checker API</h4>
				</div>
			</div>
            <div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbrib-browse"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Our Result Builder API</h4>
				</div>
			</div>
            <div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbri-cash"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Online Payment</h4>
				</div>
			</div>
            <div class="col-md-6 col-lg-3 row-item">
				<div class="wrapper">
					<div class="card-img pb-3 align-center">
						<span class="mbr-iconfont mbrib-calendar"></span>
					</div>
					<h4 class="mbr-fonts-style mbr-card-title align-center display-7">Event Management</h4>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="mbr-section extForm cid-sK1AFmmmzn" id="extForm2-2v">

    

    
   <div class="container">
        <div class="media-container-row">
            <div class="col-md-6 col-lg-6 block-content">
                <div class="form-block">
                    <div class="bg"></div>
                    <div class="form-wrap" data-form-type="formoid">
<!--Formbuilder Form-->
<form action="https://mobirise.com/" method="POST" class="mbr-form form-with-styler" data-form-title="School portal Form"><input type="hidden" name="email" data-form-email="true" value="SXGS2yOdmYSss+EuAYMxeB6pqpnIu7fOXVIB+6MQATVzs8aaODVy7yOASSmlTwJo6K4afnpA8jHDBiavI/6jKCgeW7Gs2cdSvH/xkCBbOpKcpu1H51cTuYLoCbWNTpot.vSzcoG5rXz/8oL7sVZr/2SgsATVyjhFaQErLUEcBX+ihBnQeDaf+VhJuzEy8ouW+7mSyARC2dwXh1TH9PUToMpn6nCNZIQeQ182FYhsq2O/FokyCB941+YulPpdxs3HS">
<div class="form-row">
<div hidden="hidden" data-form-alert="" class="alert alert-success col-12">Thanks for filling out the form, we will contect you soon!</div>
<div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
</div>
</div>
<div class="dragArea form-row">
<div class="col-md-12">
<h4 class="mbr-fonts-style mb-4 mbr-fonts-style display-5">Ready to get started?</h4>
</div>
<div class="col-lg-6 col-md-12 col-sm-12 form-group " data-for="name">
<input type="text" name="name" placeholder="Your Name" data-form-field="Name" required="required" class="form-control input display-7" value="" id="name-extForm2-2v">
</div>
<div data-for="phone" class="col-lg-6 col-md-12 col-sm-12 form-group">
<input type="text" name="phone" placeholder="Phone Number" data-form-field="phone" class="form-control display-7" required="required" value="" id="phone-extForm2-2v">
</div>
<div data-for="email" class="col-md-12 form-group">
<input type="text" name="email" placeholder="Email" data-form-field="Email" class="form-control input display-7" required="required" value="" id="email-extForm2-2v">
</div>

<div data-for="message" class="col-md-12 form-group">
<textarea name="message" placeholder="Have any question?" data-form-field="Message" class="form-control input display-7" id="message-extForm2-2v"></textarea>
</div>
<div class="col-md-12 input-group-btn mt-2"><button type="submit" class="btn btn-primary btn-form btn-bgr display-4">Request for Quote</button></div>
</div>
</form><!--Formbuilder Form-->
</div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6">
                <div class="text-block">
                    <h2 class="mb-4 mbr-fonts-style mbr-section-title display-2">Let’s Get <strong>in Touch</strong></h2>
                    <h3 class="mbr-section-subtitle mbr-fonts-style mb-4 display-5">
                        Whatever types of questions you'll have, feel free to get in touch with us!
                    </h3>
                    
                    
                </div>
                <p class="mb-4 mbr-fonts-style subtext display-7 pt-5">*We dont share your personal info with anyone..</p>
            </div>
        </div>
    </div>
</section>

<section class="extFooter cid-sJtzoprMgq" id="extFooter18-1m">

    

    


    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1380px" height="760px" viewBox="0 0 1380 760" preserveAspectRatio="xMidYMid meet">
        <defs id="svgEditorDefs">
            <polygon id="svgEditorShapeDefs" style="fill:khaki;stroke:black;vector-effect:non-scaling-stroke;stroke-width:0px;"></polygon>
        </defs>
        <rect id="svgEditorBackground" x="0" y="0" width="1380" height="760" style="fill: none; stroke: none;"></rect>
        <path d="M0.3577131120350206,0.819491525482845h-1.5000000000000355ZM0.3577131120350206,-3.1805084745172603h-1.5000000000000355ZM-0.14228688796500222,-4.180508474517258h5.000000000000002a5,5,0,0,1,0,6.00000000000003h-5.000000000000025a5,5,0,0,0,0,-6.00000000000003ZM5.8577131120349835,-1.1805084745172634h1.0000000000000249Z" style="fill:khaki; stroke:black; vector-effect:non-scaling-stroke;stroke-width:0px;" id="e2_shape" transform="matrix(1.01506 82.3743 -245.478 0.34062 392.311 526.125)"></path>
    </svg>


    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-12 col-lg-4">
                

                <p class="mbr-text align-left text1 mbr-fonts-style display-4">We are a team of programmers, who took it upon themselfs in helping schools in developments and intergrate of an online result checker platform to their existing website.</p>

                <div class="social-list align-left">
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="#" target="_blank">
                            <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon" style="color: rgb(87, 70, 139); fill: rgb(87, 70, 139);"></span>
                        </a>
                    </div>
                    
                    

                </div>


            </div>
            <div class="col-12 col-md-12 col-lg-4 mbr-fonts-style display-4">
                <h5 class="pb-3 align-left">
                    Contact Info
                </h5>


                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-map-pin mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">24A Rukpakwolusi, By Eliozu</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-pin mobi-mbri"></span></div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">Porthaircourt, Rivers State Nigeria</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-letter mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">info@resultchecker.com.ng</h4>
                    </div>
                </div>

                <div class="item">
                    <div class="card-img"><span class="mbr-iconfont img1 mobi-mbri-phone mobi-mbri"></span>
                    </div>
                    <div class="card-box">
                        <h4 class="item-title align-left mbr-fonts-style display-4">
<div><span style="font-size: 1rem;">+ (234) 90-6684-9761</span><br></div></h4>
                    </div>
                </div>

                


            </div>
     
            <div class="col-12 col-md-13 col-lg-4 mbr-fonts-style display-7">
                <h5 class="pb-3 align-left">Offline Result Builder</h5>
                <p class="mbr-text align-left text2 mbr-fonts-style display-4">
                    You can now compute your school results even without active internet connection on your &nbsp;smartphone. Click on below link to get our Progresive Web App(PWA) installed on your smartphone.</p>

                <div class="mbr-section-btn align-left"><a class="btn btn-md btn-white-outline display-4" href="https://builder.resultchecker.com.ng" target="_blank"><span class="mbri-devices mbr-iconfont mbr-iconfont-btn"></span>Result Builder</a></div>

            </div>
        </div>


    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/formstyler/jquery.formstyler.js"></script>
  <script src="assets/formstyler/jquery.formstyler.min.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="assets/dropdown/js/nav-dropdown.js"></script>
  <script src="assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/datepicker/jquery.datetimepicker.full.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience.">
  
</body>
</html>